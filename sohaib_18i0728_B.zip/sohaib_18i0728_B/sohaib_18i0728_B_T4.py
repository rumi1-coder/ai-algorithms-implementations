fav_food_item=[['pizza','burgur','hotdog'],['pasta','hotdog'],['pasta'],['rice','pasta'],['pizza']]
counter=0
for item in fav_food_item:
    for c in item:
       counter=counter+1
       for d in c:
           if item[]
